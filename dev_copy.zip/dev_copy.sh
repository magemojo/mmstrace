#!/bin/bash

################################################################
##
##   MageMojo Live -> Dev Copy Script
##   Written By: Ian Carey
##   Last Update: Sept 8, 2020
##
#################################################################

export PATH=/bin:/usr/bin:/usr/local/bin
TODAY=`date +"%d%b%Y"`

usage() { echo "Usage: $0 [-d </srv/public_html>] [-u <transfer>] [-h <34.237.143.58>] [-p <29259>] [-b <https://cabofpsmrjx8ofsh.mojostratus.io/>] [-v <1|2]" 1>&2; exit 1; }

while [ "$#" -gt 0 ]; do
  case "$1" in
    -d) REMOTE_HTML="$2"; shift 2;;
    -u) SSH_USER="$2"; shift 2;;
    -h) SSH_HOST="$2"; shift 2;;
    -p) SSH_PORT="$2"; shift 2;;
    -b) BASE_URL="$2"; shift 2;;
    -v) MAGENTO_VERSION="$2"; shift 2;;

    -*) usage;;
    *) usage;;
  esac
done

if [ -z "${REMOTE_HTML}" ] || [ -z "${SSH_USER}" ] || [ -z "${SSH_HOST}" ] || [ -z "${SSH_PORT}" ] || [ -z "${BASE_URL}" ] || [ -z "${MAGENTO_VERSION}" ]; then
    usage
fi

if [[ "${MAGENTO_VERSION}" -eq 1 ]];
then
  echo "Not Supported"
  exit 1
fi
#Create SSH-Key if it does not exist
cd ~ || exit
FILE=~/.ssh/${SSH_USER}
if test -f "$FILE"; then
   echo -e "\e[92mKey Exists\e[0m";
else
   echo -e "\e[33mCreating SSH Key\e[0m";
   ssh-keygen -t rsa -N "" -f ~/.ssh/${SSH_USER}
fi

#Read SSH-Key
echo -e "\e[33mCreate an SSH User in Stratus for on the HOST instance named \e[32m${SSH_USER}\e[33m, and paste this key in authorized keys.\e[0m"
cat ~/.ssh/${SSH_USER}.pub
printf "\n"
read -n 1 -s -r -p "Press any key to continue"

#GetIp for Whitelist
curl http://ipcheck.com/ > ~/ip.log>&1
echo -e "\e[33mAdd user \e[32mtransfer\e[33m to the whitelist in Stratus for on the HOST instance with the following IP.\e[0m"
cat ~/ip.log
printf "\n"
read -n 1 -s -r -p "Press any key to continue"
rm ~/ip.log
printf "\n"

#Get Remote Commands list.
wget https://icarey.net/remote_commands.list
printf "\n"

#Connect to HOST and make a database backup with dev_copy_remote_database.sh
echo -e "\e[92mStarting Remote Database Backup\e[0m"
if cat remote_commands.list | ssh -p ${SSH_PORT} -i $HOME/.ssh/${SSH_USER} ${SSH_USER}@${SSH_HOST};
then
   echo -e "\e[92mRemote Database Backup Complete\e[0m"
   rm remote_commands.list
else
   echo -e "\e[31mError With Remote Database Backup\e[0m"
   rm remote_commands.list
   exit 1
fi
# Remove current public_html
echo -e "\e[92mRemoving LOCAL public_html.\e[0m"
if rm -rf /srv/public_html;
then
  echo -e "\e[92mRemoving LOCAL public_html Successful!\e[0m"
else
   echo -e "\e[31mRemoving LOCAL public_html failed. Make sure it is /srv/public_html \e[0m"
    exit 1
fi

# Start Database Rsync From remote host.
echo -e "\e[92mStarting Database RSYNC from Source ${SSH_HOST}.\e[0m"
mkdir -p /srv/backups
if rsync -Pav -e "ssh -p ${SSH_PORT} -i $HOME/.ssh/${SSH_USER}" ${SSH_USER}@${SSH_HOST}:/srv/backups/${TODAY} /srv/backups/;
then
    echo -e "\e[92mDatabase RSYNC was Successful!!\e[0m"
else
    echo -e "\e[31mRSYNC FAILED, Check the HOST, PORT, and if you created the USER and added to the Whitelist in Stratus and try again.\e[0m"
    exit 1
fi

# Start File Rsync From remote host.
echo -e "\e[92mStarting Files RSYNC from Source ${SSH_HOST}.\e[0m"
mkdir -p "/srv/public_html"
if rsync -Pav -e "ssh -p ${SSH_PORT} -i $HOME/.ssh/${SSH_USER}" ${SSH_USER}@${SSH_HOST}:${REMOTE_HTML}/ /srv/public_html;
then
    echo -e "\e[92mRSYNC was Successful!!\e[0m"
else
    echo -e "\e[31mRSYNC FAILED, Check the HOST, PORT, and if you created the USER and added to the Whitelist in Stratus and try again.\e[0m"
    exit 1
fi

#Getting Database Credentials
echo -e "\e[33mReading Database Credentials\e[0m"
/usr/share/stratus/cli database.config > cred.log 2>&1
MYSQL_USER=$(< cred.log grep Username | awk '{print $3}' | cut -c3- | rev | cut -c4- | rev)
DATABASE_NAME=$(< cred.log grep Username | awk '{print $7}' | cut -c3- | rev | cut -c4- | rev)
MYSQL_PASSWORD=$(< cred.log grep Username | awk '{print $14}' | cut -c3- | rev | cut -c4- | rev)
rm cred.log

#IMPORT THE Database
echo -e "\e[33mConfiguring The Database\e[0m"
cd /srv/backups/"${TODAY}" || exit
echo -e "\e[33mFixing Super Priv Error\e[0m"
sed -E 's/DEFINER=`[^`]+`@`[^`]+`/DEFINER=CURRENT_USER/g' db_${TODAY}.sql > fixed_dump.sql
echo -e "\e[33mDropping Old Database\e[0m"
mysql -h mysql -u ${MYSQL_USER} -p${MYSQL_PASSWORD} -e "drop database ${DATABASE_NAME};"
echo -e "\e[33mCreating New Database\e[0m"
mysql -h mysql -u ${MYSQL_USER} -p${MYSQL_PASSWORD} -e "create database ${DATABASE_NAME};"
echo -e "\e[33mImporting Database"
if mysql -h mysql -u ${MYSQL_USER} -p${MYSQL_PASSWORD} ${DATABASE_NAME} < fixed_dump.sql;
then
    echo -e "\e[92mDatabase import was Successful!!\e[0m"
    rm fixed_dump.sql
else
    echo -e "\e[31mDatabase import failed, Check if it was shot down by POC. If so report to Jackie\e[0m"
    exit 1
fi

#Create new env.php
echo -e "\e[33mCreating New Magento Config\e[0m"
mv /srv/public_html/app/etc/env.php /srv/public_html/app/etc/env.php_mm
touch /srv/public_html/app/etc/env.php
if [[ "${MAGENTO_VERSION}" -eq 1 ]];
then
  echo "Not Supported"
else
  CONFIG_FILE="/srv/public_html/app/etc/env.php_mm"
  ADMIN_PATH=$(grep -Po "(?<='frontName' => ').*(?=')" $CONFIG_FILE)
  CRYPT_KEY=$(grep -Po "(?<='key' => ').*(?=')" $CONFIG_FILE)
  MYSQL_HOST='mysql'
  TB_PREFIX=$(grep -Po "(?<='table_prefix' => ').*(?=',)" $CONFIG_FILE)
  if grep -Poq "    'queue' => \[" $CONFIG_FILE;
  then
    echo -e "Building Config with RabbitMQ"
    wget https://icarey.net/m2_conf_rabbit.temp -O m2_config.templ
    RABBIT_USER=$(grep -Po "(?<=            'user' => ').*(?=',)" $CONFIG_FILE)
    RABBIT_PASSWORD=$(grep -Po "(?<=            'password' => ').*(?=',)" $CONFIG_FILE | sed -n 2p)
    sed -e "s/\${ADMIN_PATH}/${ADMIN_PATH}/" -e "s/\${CRYPT_KEY}/${CRYPT_KEY}/" -e "s/\${MYSQL_HOST}/${MYSQL_HOST}/"  -e "s/\${MYSQL_USER}/${MYSQL_USER}/"   -e "s/\${MYSQL_PASSWORD}/${MYSQL_PASSWORD}/"   -e "s/\${DATABASE_NAME}/${DATABASE_NAME}/" -e "s/\${TB_PREFIX}/${TB_PREFIX}/" -e "s/\${RABBIT_USER}/${RABBIT_USER}/" -e "s/\${RABBIT_PASSWORD}/${RABBIT_PASSWORD}/" m2_config.templ > /srv/public_html/app/etc/env.php
  else
    echo -e "Building Config with out RabbitMQ"
    wget https://icarey.net/m2_conf.temp -O m2_config.templ
    sed -e "s/\${ADMIN_PATH}/${ADMIN_PATH}/" -e "s/\${CRYPT_KEY}/${CRYPT_KEY}/" -e "s/\${MYSQL_HOST}/${MYSQL_HOST}/"  -e "s/\${MYSQL_USER}/${MYSQL_USER}/"   -e "s/\${MYSQL_PASSWORD}/${MYSQL_PASSWORD}/"   -e "s/\${DATABASE_NAME}/${DATABASE_NAME}/" -e "s/\${TB_PREFIX}/${TB_PREFIX}/" m2_config.templ > /srv/public_html/app/etc/env.php
  fi
rm m2_config.templ
fi

#Update Base URLS
echo -e "\e[33mChanging Base URLs\e[0m"
if mysql -h mysql -u ${MYSQL_USER} -p${MYSQL_PASSWORD} ${DATABASE_NAME} -e "update ${TB_PREFIX}core_config_data set value='${BASE_URL}' where path like 'web/%secure/base_url' AND scope='default';";
then
  echo -e "\e[92mBase URL Change was Successful!!\e[0m"
else
  echo -e "\e[31mBase URL change failed, Manually change baseurls\e[0m"
fi

#Update Cookie Domain
echo -e "\e[33mChanging Cookie Domain\e[0m"
if mysql -h mysql -u ${MYSQL_USER} -p${MYSQL_PASSWORD} ${DATABASE_NAME} -e "update ${TB_PREFIX}core_config_data set value='.mojostratus.io' where path like '%cookie_domain%' and scope_id=0";
then
  echo -e "\e[92mCookie Domain Change was Successful!!\e[0m"
else
  echo -e "\e[31mCookie Domain change failed, Manually change Cookie Domain\e[0m"
fi

# Reindex and clear cache
cd /srv/public_html
php bin/magento cache:enable
php bin/magento indexer:set-mode schedule
php bin/magento indexer:reindex
/usr/share/stratus/cli cache.all.clear

echo -e "\e[33m Finished! Check if the site is loading properly. ${BASE_URL}\e[0m"
