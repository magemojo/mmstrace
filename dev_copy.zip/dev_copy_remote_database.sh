#!/bin/bash

################################################################
##
##   Magento Remote Database Backup Script
##   Written By: Ian Carey
##   Last Update: Sept 8, 2020
##
################################################################

export PATH=/bin:/usr/bin:/usr/local/bin
TODAY=`date +"%d%b%Y"`

################################################################
################## Update below values  ########################
BACKUP_PATH='/srv/backups'
MYSQL_HOST='mysql'
MYSQL_PORT='3306'
MYSQL_USER=$1  #unused, using root
MYSQL_PASSWORD=$3
DATABASE_NAME=$2
#################################################################

mkdir -p ${BACKUP_PATH}/"${TODAY}"
echo -e "\e[33mDatabase Backup started for - ${DATABASE_NAME}\e[0m"

mysqldump --skip-lock-tables --single-transaction --verbose -h ${MYSQL_HOST} -u root -p"${MYSQL_PASSWORD}" ${DATABASE_NAME} > ${BACKUP_PATH}/${TODAY}/db_${TODAY}.sql

if mysqldump; then
  echo -e "\e[92mDatabase backup successfully completed\e[0m"
else
  echo -e "\e[31mError found during backup\e[0m"
  exit 1
fi
### End of script ####
